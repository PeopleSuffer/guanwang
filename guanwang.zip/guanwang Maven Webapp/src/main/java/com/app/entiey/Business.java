package com.app.entiey;

public class Business {
	private int id;
	private String businessTitle;
	private String businessContent;
	private String createTime;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the businessTitle
	 */
	public String getBusinessTitle() {
		return businessTitle;
	}
	/**
	 * @param businessTitle the businessTitle to set
	 */
	public void setBusinessTitle(String businessTitle) {
		this.businessTitle = businessTitle;
	}
	/**
	 * @return the businessContent
	 */
	public String getBusinessContent() {
		return businessContent;
	}
	/**
	 * @param businessContent the businessContent to set
	 */
	public void setBusinessContent(String businessContent) {
		this.businessContent = businessContent;
	}
	/**
	 * @return the createTime
	 */
	public String getCreateTime() {
		return createTime;
	}
	/**
	 * @param createTime the createTime to set
	 */
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	
}
